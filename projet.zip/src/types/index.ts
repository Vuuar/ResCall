export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  business_name: string;
  phone_number?: string;
  subscription_tier?: string;
  subscription_status?: string;
  trial_ends_at?: string;
  stripe_customer_id?: string;
  stripe_subscription_id?: string;
  created_at: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  features: string[];
  limits: {
    appointments: number;
    services: number;
    staff: number;
    voice_messages: boolean;
    calendar_integration: boolean;
    analytics: boolean;
  };
  recommended?: boolean;
}

export interface ProfessionalSettings {
  id: string;
  professional_id: string;
  welcome_message: string;
  confirmation_message: string;
  reminder_message: string;
  reminder_time: number;
  voice_enabled: boolean;
  voice_greeting?: string;
  appointment_buffer: number;
  calendar_integration: string;
  calendar_sync_enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface Service {
  id: string;
  professional_id: string;
  name: string;
  description?: string;
  duration: number;
  price: number;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Client {
  id: string;
  professional_id: string;
  first_name: string;
  last_name: string;
  phone_number: string;
  email?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Appointment {
  id: string;
  professional_id: string;
  client_id: string;
  service_id: string;
  start_time: string;
  end_time: string;
  status: 'scheduled' | 'confirmed' | 'cancelled' | 'completed';
  notes?: string;
  reminder_sent: boolean;
  created_at: string;
  updated_at: string;
  // These are joined fields
  client?: Client;
  service?: Service;
}

export interface WorkingHours {
  id: string;
  professional_id: string;
  day_of_week: number;
  start_time?: string;
  end_time?: string;
  is_working_day: boolean;
  created_at: string;
  updated_at: string;
}

export interface TimeOff {
  id: string;
  professional_id: string;
  start_time: string;
  end_time: string;
  description?: string;
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  professional_id: string;
  client_id?: string;
  phone_number: string;
  status: 'active' | 'completed' | 'archived';
  last_message_at: string;
  created_at: string;
  updated_at: string;
  // These are joined fields
  client?: Client;
  messages?: Message[];
}

export interface Message {
  id: string;
  conversation_id: string;
  direction: 'inbound' | 'outbound';
  content: string;
  content_type: 'text' | 'voice' | 'image';
  media_url?: string;
  sent_at: string;
  created_at: string;
}
